// routes/stockRoutes.js - UPDATED
import express from "express";
import {
  createPurchase,
  getPurchases,
  getPurchaseById,
  getTaxSummary,
  updatePurchaseStatus,
  deletePurchase,

  getFuelStocks,
  getFuelStock,
  updateFuelStock,
  deleteFuelStock,
  getLatestStocks,
  getFuelStockStats,
  createStockAdjustment,
  getStockAdjustments,
  getAdjustmentStats
} from "../controllers/fuelStockController.js";
import { protect } from "../middleware/authMiddleware.js";

const router = express.Router();

router.use(protect);

// Fuel stock routes
router.get("/", getFuelStocks);
router.get("/latest", getLatestStocks);
router.get("/stats", getFuelStockStats);
router.get("/:id", getFuelStock);
router.put("/:id", updateFuelStock);
router.delete("/:id", deleteFuelStock);

// Stock adjustment routes
router.post("/adjustment", createStockAdjustment);
router.get("/adjustments/history", getStockAdjustments);
router.get("/adjustments/stats", getAdjustmentStats);


router.post("/purchase", createPurchase);
router.get("/", getPurchases);
router.get("/tax/summary", getTaxSummary);
router.get("/:id", getPurchaseById);
router.put("/:id/status", updatePurchaseStatus);
router.delete("/:id", deletePurchase);

export default router;