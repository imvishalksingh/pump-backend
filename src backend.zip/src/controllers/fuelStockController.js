// controllers/fuelStockController.js - UPDATED with mongoose import
import mongoose from "mongoose";
import FuelStock from "../models/FuelStock.js";
import StockAdjustment from "../models/StockAdjustment.js";
import Notification from "../models/Notification.js";
import asyncHandler from "express-async-handler";
import Purchase from "../models/Purchase.js";

// Helper: Generate or resolve low stock alerts
const handleLowStockAlert = async (stock) => {
  try {
    if (!stock?.product) return;

    // If below 30% capacity -> create alert
    if (stock.currentLevel < 30) {
      const existing = await Notification.findOne({
        type: "Stock",
        description: { $regex: stock.product, $options: "i" },
        status: "Unread",
      });

      if (!existing) {
        await Notification.create({
          type: "Stock",
          description: `${stock.product} stock below 30%`,
          priority: stock.currentLevel < 15 ? "High" : "Medium",
          status: "Unread",
        });
        console.log(`🔔 Low stock alert created for ${stock.product}`);
      }
    }

    // If refilled (> 40%) -> mark previous alerts as Read
    if (stock.currentLevel > 40) {
      await Notification.updateMany(
        {
          type: "Stock",
          description: { $regex: stock.product, $options: "i" },
          status: "Unread",
        },
        { status: "Read" }
      );
    }
  } catch (err) {
    console.error("⚠️ Error handling stock alert:", err.message);
  }
};

// @desc    Create new fuel stock entry
// @route   POST /api/stock
// @access  Private
export const createFuelStock = asyncHandler(async (req, res) => {
  console.log("📦 Received stock purchase data:", req.body);
  
  const {
    product,
    tank,
    invoiceNumber,
    purchaseQuantity,
    purchaseValue,
    vehicleNumber,
    density,
    ratePerLiter,
    supplier
  } = req.body;

  // Debug: Check each field
  console.log("🔍 Field check:");
  console.log("- product:", product, !!product);
  console.log("- tank:", tank, !!tank);
  console.log("- invoiceNumber:", invoiceNumber, !!invoiceNumber);
  console.log("- purchaseQuantity:", purchaseQuantity, !!purchaseQuantity);
  console.log("- purchaseValue:", purchaseValue, !!purchaseValue);
  console.log("- ratePerLiter:", ratePerLiter, !!ratePerLiter);
  console.log("- supplier:", supplier, !!supplier);
  console.log("- vehicleNumber:", vehicleNumber);
  console.log("- density:", density);

  // Validate required fields with specific error messages
  const missingFields = [];
  if (!product) missingFields.push("product");
  if (!tank) missingFields.push("tank");
  if (!invoiceNumber) missingFields.push("invoiceNumber");
  if (!purchaseQuantity) missingFields.push("purchaseQuantity");
  if (!purchaseValue) missingFields.push("purchaseValue");
  if (!ratePerLiter) missingFields.push("ratePerLiter");
  if (!supplier) missingFields.push("supplier");

  if (missingFields.length > 0) {
    console.log("❌ Missing required fields:", missingFields);
    res.status(400);
    throw new Error(`Missing required fields: ${missingFields.join(', ')}`);
  }

  // Check if invoice number already exists
  const existingInvoice = await FuelStock.findOne({ invoiceNumber });
  if (existingInvoice) {
    console.log("❌ Duplicate invoice number:", invoiceNumber);
    res.status(400);
    throw new Error("Invoice number already exists");
  }

  // Validate tank exists and matches product
  const TankConfig = mongoose.model("TankConfig");
  const tankConfig = await TankConfig.findById(tank);
  if (!tankConfig) {
    console.log("❌ Tank not found:", tank);
    res.status(404);
    throw new Error("Tank not found");
  }

  if (tankConfig.product !== product) {
    console.log("❌ Tank-product mismatch:", tankConfig.product, "!=", product);
    res.status(400);
    throw new Error("Selected tank does not match the product");
  }

  // Validate purchase quantity doesn't exceed tank capacity
  const latestStock = await FuelStock.findOne({ tank }).sort({ createdAt: -1 });
  const currentStock = latestStock ? latestStock.closingStock : 0;
  const newStock = currentStock + parseFloat(purchaseQuantity);
  
  if (newStock > tankConfig.capacity) {
    console.log("❌ Capacity exceeded:", newStock, ">", tankConfig.capacity);
    res.status(400);
    throw new Error(`Purchase quantity exceeds tank capacity. Current: ${currentStock}L, Capacity: ${tankConfig.capacity}L, New total would be: ${newStock}L`);
  }

  // Create the fuel stock entry
  const fuelStockData = {
    product,
    tank,
    invoiceNumber: invoiceNumber.trim(),
    purchaseQuantity: parseFloat(purchaseQuantity),
    purchaseValue: parseFloat(purchaseValue),
    ratePerLiter: parseFloat(ratePerLiter),
    supplier: supplier.trim()
  };

  // Add optional fields if provided
  if (vehicleNumber) fuelStockData.vehicleNumber = vehicleNumber.trim();
  if (density) fuelStockData.density = parseFloat(density);

  console.log("💾 Creating fuel stock with data:", fuelStockData);

  const fuelStock = await FuelStock.create(fuelStockData);

  // Handle low stock alerts
  await handleLowStockAlert(fuelStock);

  console.log("✅ Stock purchase recorded successfully:", fuelStock._id);

  res.status(201).json({
    success: true,
    message: "Stock purchase recorded successfully",
    fuelStock
  });
});

// @desc    Get all fuel stock entries
// @route   GET /api/stock
// @access  Private
export const getFuelStocks = asyncHandler(async (req, res) => {
  const { product, tank, startDate, endDate } = req.query;

  let query = {};
  if (product && product !== "all") query.product = product;
  if (tank && tank !== "all") query.tank = tank;
  
  if (startDate && endDate) {
    query.date = { 
      $gte: new Date(startDate), 
      $lte: new Date(endDate) 
    };
  }

  const fuelStocks = await FuelStock.find(query)
    .populate("tank", "name capacity product currentStock")
    .sort({ createdAt: -1 });

  res.json(fuelStocks);
});

// @desc    Get latest stock for each product
// @route   GET /api/stock/latest
// @access  Private
export const getLatestStocks = asyncHandler(async (req, res) => {
  const latestStocks = await FuelStock.aggregate([
    { $sort: { createdAt: -1 } },
    {
      $group: {
        _id: "$tank",
        latestEntry: { $first: "$$ROOT" },
      },
    },
    { $replaceRoot: { newRoot: "$latestEntry" } },
  ]);

  // Populate tank information
  const TankConfig = mongoose.model("TankConfig");
  const populatedStocks = await TankConfig.populate(latestStocks, { path: 'tank' });

  res.json(populatedStocks);
});

// @desc    Get fuel stock statistics
// @route   GET /api/stock/stats
// @access  Private
export const getFuelStockStats = asyncHandler(async (req, res) => {
  const stats = await FuelStock.aggregate([
    { $sort: { createdAt: -1 } },
    {
      $group: {
        _id: "$product",
        latestStock: { $first: "$closingStock" },
        capacity: { $first: "$capacity" },
        currentLevel: { $first: "$currentLevel" },
        alert: { $first: "$alert" },
      },
    },
    {
      $project: {
        product: "$_id",
        closingStock: "$latestStock",
        capacity: 1,
        currentLevel: 1,
        alert: 1,
        _id: 0,
      },
    },
  ]);

  const totalCapacity = stats.reduce((sum, item) => sum + item.capacity, 0);
  const totalCurrent = stats.reduce((sum, item) => sum + item.closingStock, 0);
  const averageLevel = Math.round((totalCurrent / totalCapacity) * 100);
  const lowStockAlerts = stats.filter((item) => item.alert).length;

  res.json({
    products: stats,
    totalCapacity,
    totalCurrent,
    averageLevel,
    lowStockAlerts,
  });
});

// @desc    Get single fuel stock entry
// @route   GET /api/stock/:id
// @access  Private
export const getFuelStock = asyncHandler(async (req, res) => {
  const fuelStock = await FuelStock.findById(req.params.id)
    .populate("tank", "name capacity product currentStock");
  if (!fuelStock) {
    res.status(404);
    throw new Error("Fuel stock entry not found");
  }
  res.json(fuelStock);
});

// @desc    Update fuel stock entry
// @route   PUT /api/stock/:id
// @access  Private
export const updateFuelStock = asyncHandler(async (req, res) => {
  const fuelStock = await FuelStock.findById(req.params.id);
  if (!fuelStock) {
    res.status(404);
    throw new Error("Fuel stock entry not found");
  }

  const updatedFuelStock = await FuelStock.findByIdAndUpdate(
    req.params.id,
    req.body,
    { new: true, runValidators: true }
  );

  // ✅ Check for low stock alerts
  await handleLowStockAlert(updatedFuelStock);

  res.json(updatedFuelStock);
});

// @desc    Delete fuel stock entry
// @route   DELETE /api/stock/:id
// @access  Private
export const deleteFuelStock = asyncHandler(async (req, res) => {
  const fuelStock = await FuelStock.findById(req.params.id);
  if (!fuelStock) {
    res.status(404);
    throw new Error("Fuel stock entry not found");
  }

  await FuelStock.findByIdAndDelete(req.params.id);
  res.json({ message: "Fuel stock entry removed successfully" });
});

// @desc    Create stock adjustment (NOW REQUIRES AUDITOR APPROVAL)
// @route   POST /api/stock/adjustment
// @access  Private
export const createStockAdjustment = asyncHandler(async (req, res) => {
  const { product, adjustmentType, quantity, reason, tank, dipReading, calculatedQuantity } = req.body;

  if (!product || !adjustmentType || !quantity || !reason || !tank) {
    res.status(400);
    throw new Error("Please provide all required fields");
  }

  const latestStock = await FuelStock.findOne({ product }).sort({ createdAt: -1 });
  if (!latestStock) {
    res.status(404);
    throw new Error(`No stock found for product: ${product}`);
  }

  const previousStock = latestStock.closingStock;
  let newStock = previousStock;

  // For daily updates, use the calculated quantity directly
  if (adjustmentType === "daily_update") {
    newStock = parseFloat(quantity);
  } else {
    // For other types, require admin approval
    switch (adjustmentType) {
      case "addition":
        newStock = previousStock + parseFloat(quantity);
        break;
      case "deduction":
        newStock = previousStock - parseFloat(quantity);
        if (newStock < 0) {
          res.status(400);
          throw new Error("Deduction quantity cannot exceed current stock");
        }
        break;
      case "calibration":
        newStock = parseFloat(quantity);
        break;
      default:
        res.status(400);
        throw new Error("Invalid adjustment type");
    }
  }

  // Determine status based on adjustment type
  let status = "Pending";
  if (adjustmentType === "daily_update") {
    status = "Approved"; // Daily updates auto-approve
  }

  const stockAdjustment = await StockAdjustment.create({
    product,
    tank,
    adjustmentType,
    quantity: parseFloat(quantity),
    dipReading: dipReading ? parseFloat(dipReading) : undefined,
    calculatedQuantity: calculatedQuantity ? parseFloat(calculatedQuantity) : undefined,
    reason,
    previousStock,
    newStock,
    adjustedBy: req.user._id,
    status
  });

  let responseData = {
    message: adjustmentType === "daily_update" 
      ? "Daily stock update recorded successfully" 
      : "Stock adjustment request submitted for auditor approval",
    adjustment: stockAdjustment
  };

  // If daily update, create FuelStock entry immediately
  if (adjustmentType === "daily_update") {
    const newFuelStockEntry = await FuelStock.create({
      product,
      openingStock: previousStock,
      purchases: 0,
      sales: 0,
      capacity: latestStock.capacity,
      rate: latestStock.rate,
      amount: 0,
      supplier: "System",
      invoiceNumber: `DAILY_${Date.now()}`
    });

    // Update the adjustment with approved status
    stockAdjustment.status = "Approved";
    stockAdjustment.approvedBy = req.user._id;
    stockAdjustment.approvedAt = new Date();
    await stockAdjustment.save();

    // Add the stock entry to response
    responseData.updatedStock = newFuelStockEntry;
    
    console.log(`✅ Daily stock update recorded: ${newFuelStockEntry._id}`);
  }

  console.log(`📝 Stock adjustment created: ${stockAdjustment._id} (Status: ${stockAdjustment.status})`);

  res.status(201).json(responseData);
});

// @desc    Get stock adjustment history
// @route   GET /api/stock/adjustments/history
// @access  Private
export const getStockAdjustments = asyncHandler(async (req, res) => {
  const { product, startDate, endDate, status } = req.query;

  let query = {};
  if (product && product !== "all") query.product = product;
  if (status && status !== "all") query.status = status;
  
  if (startDate && endDate) {
    query.createdAt = {
      $gte: new Date(startDate),
      $lte: new Date(endDate),
    };
  }

  const adjustments = await StockAdjustment.find(query)
    .populate("adjustedBy", "name email")
    .populate("approvedBy", "name email")
    .sort({ createdAt: -1 });

  res.json(adjustments);
});

// @desc    Get stock adjustment statistics
// @route   GET /api/stock/adjustments/stats
// @access  Private
export const getAdjustmentStats = asyncHandler(async (req, res) => {
  const { days = 30 } = req.query;

  const startDate = new Date();
  startDate.setDate(startDate.getDate() - parseInt(days));

  const stats = await StockAdjustment.aggregate([
    { $match: { createdAt: { $gte: startDate } } },
    {
      $group: {
        _id: { type: "$adjustmentType", status: "$status" },
        count: { $sum: 1 },
        totalQuantity: { $sum: "$quantity" },
      },
    },
    {
      $project: {
        adjustmentType: "$_id.type",
        status: "$_id.status",
        count: 1,
        totalQuantity: 1,
        _id: 0,
      },
    },
  ]);

  const totalAdjustments = await StockAdjustment.countDocuments({
    createdAt: { $gte: startDate },
  });

  const pendingCount = await StockAdjustment.countDocuments({
    createdAt: { $gte: startDate },
    status: "Pending"
  });

  res.json({
    period: `${days} days`,
    totalAdjustments,
    pendingCount,
    byType: stats,
  });
});


// @desc    Create new purchase with tax breakdown
// @route   POST /api/purchases
// @access  Private
export const createPurchase = asyncHandler(async (req, res) => {
  const {
    purchaseType,
    supplier,
    invoiceNumber,
    invoiceDate,
    // Fuel purchase fields
    product,
    tank,
    purchaseQuantity,
    purchaseValue,
    ratePerLiter,
    vehicleNumber,
    density,
    vat,
    otherCharges,
    // GST fields
    taxableValue,
    cgst,
    sgst,
    igst,
    discount,
    totalValue,
    // Asset fields
    assetName,
    assetCategory,
    assetDescription,
    notes
  } = req.body;

  // Validate required fields
  if (!purchaseType || !supplier || !invoiceNumber || !invoiceDate) {
    res.status(400);
    throw new Error("Please provide all required fields: purchaseType, supplier, invoiceNumber, invoiceDate");
  }

  // Check for duplicate invoice number
  const existingPurchase = await Purchase.findOne({ invoiceNumber });
  if (existingPurchase) {
    res.status(400);
    throw new Error("Invoice number already exists");
  }

  // Create purchase record
  const purchaseData = {
    purchaseType,
    supplier,
    invoiceNumber,
    invoiceDate: new Date(invoiceDate),
    totalValue: parseFloat(totalValue) || 0,
    recordedBy: req.user._id,
    notes
  };

  // Add type-specific fields
  if (purchaseType === "fuel") {
    Object.assign(purchaseData, {
      product,
      tank,
      purchaseQuantity: parseFloat(purchaseQuantity) || 0,
      purchaseValue: parseFloat(purchaseValue) || 0,
      ratePerLiter: parseFloat(ratePerLiter) || 0,
      vehicleNumber,
      density: density ? parseFloat(density) : undefined,
      vat: parseFloat(vat) || 0,
      otherCharges: parseFloat(otherCharges) || 0
    });
  } else if (purchaseType === "lube") {
    Object.assign(purchaseData, {
      product: assetName, // Use assetName as product name for lube
      taxableValue: parseFloat(taxableValue) || 0,
      cgst: parseFloat(cgst) || 0,
      sgst: parseFloat(sgst) || 0,
      igst: parseFloat(igst) || 0,
      discount: parseFloat(discount) || 0
    });
  } else if (purchaseType === "fixed-asset") {
    Object.assign(purchaseData, {
      assetName,
      assetCategory,
      assetDescription,
      taxableValue: parseFloat(taxableValue) || 0,
      cgst: parseFloat(cgst) || 0,
      sgst: parseFloat(sgst) || 0,
      igst: parseFloat(igst) || 0,
      discount: parseFloat(discount) || 0
    });
  }

  const purchase = await Purchase.create(purchaseData);

  // For fuel purchases, also create FuelStock entry
  if (purchaseType === "fuel") {
    try {
      const fuelStock = await FuelStock.create({
        product,
        tank,
        invoiceNumber,
        purchaseQuantity: parseFloat(purchaseQuantity) || 0,
        purchaseValue: parseFloat(purchaseValue) || 0,
        ratePerLiter: parseFloat(ratePerLiter) || 0,
        vehicleNumber,
        density: density ? parseFloat(density) : undefined,
        supplier
      });

      res.status(201).json({
        message: "Fuel purchase recorded successfully",
        purchase,
        fuelStock
      });
    } catch (fuelStockError) {
      // If FuelStock creation fails, delete the purchase record
      await Purchase.findByIdAndDelete(purchase._id);
      throw new Error(`Failed to create fuel stock: ${fuelStockError.message}`);
    }
  } else {
    res.status(201).json({
      message: "Purchase recorded successfully",
      purchase
    });
  }
});

// @desc    Get all purchases with filters
// @route   GET /api/purchases
// @access  Private
export const getPurchases = asyncHandler(async (req, res) => {
  const { 
    purchaseType, 
    supplier, 
    startDate, 
    endDate, 
    page = 1, 
    limit = 10 
  } = req.query;

  let query = {};

  if (purchaseType && purchaseType !== 'all') {
    query.purchaseType = purchaseType;
  }

  if (supplier && supplier !== 'all') {
    query.supplier = new RegExp(supplier, 'i');
  }

  if (startDate && endDate) {
    query.invoiceDate = {
      $gte: new Date(startDate),
      $lte: new Date(endDate)
    };
  }

  const skip = (parseInt(page) - 1) * parseInt(limit);

  const purchases = await Purchase.find(query)
    .populate("tank", "tankName capacity product")
    .populate("recordedBy", "name email")
    .sort({ invoiceDate: -1, createdAt: -1 })
    .skip(skip)
    .limit(parseInt(limit));

  const total = await Purchase.countDocuments(query);

  res.json({
    purchases,
    pagination: {
      currentPage: parseInt(page),
      totalPages: Math.ceil(total / parseInt(limit)),
      totalPurchases: total,
      hasNext: skip + purchases.length < total,
      hasPrev: parseInt(page) > 1
    }
  });
});

// @desc    Get purchase by ID
// @route   GET /api/purchases/:id
// @access  Private
export const getPurchaseById = asyncHandler(async (req, res) => {
  const purchase = await Purchase.findById(req.params.id)
    .populate("tank", "tankName capacity product")
    .populate("recordedBy", "name email")
    .populate("approvedBy", "name email");

  if (!purchase) {
    res.status(404);
    throw new Error("Purchase not found");
  }

  res.json(purchase);
});

// @desc    Get tax summaries for filing
// @route   GET /api/purchases/tax/summary
// @access  Private
export const getTaxSummary = asyncHandler(async (req, res) => {
  const { period = "month" } = req.query;
  
  let startDate, endDate;
  const now = new Date();

  if (period === "month") {
    startDate = new Date(now.getFullYear(), now.getMonth(), 1);
    endDate = new Date(now.getFullYear(), now.getMonth() + 1, 0);
  } else if (period === "quarter") {
    const quarter = Math.floor(now.getMonth() / 3);
    startDate = new Date(now.getFullYear(), quarter * 3, 1);
    endDate = new Date(now.getFullYear(), (quarter + 1) * 3, 0);
  } else {
    // Custom period or year
    startDate = new Date(now.getFullYear(), 0, 1);
    endDate = new Date(now.getFullYear(), 11, 31);
  }

  const [gstSummary, vatSummary] = await Promise.all([
    Purchase.getGSTSummary(startDate, endDate),
    Purchase.getVATSummary(startDate, endDate)
  ]);

  res.json({
    period: {
      start: startDate,
      end: endDate
    },
    gstSummary,
    vatSummary,
    overall: {
      totalPurchases: gstSummary.totalPurchases + vatSummary.totalPurchases,
      totalValue: gstSummary.totalValue + vatSummary.totalValue,
      totalTax: gstSummary.totalCGST + gstSummary.totalSGST + gstSummary.totalIGST + vatSummary.totalVAT
    }
  });
});

// @desc    Update purchase status
// @route   PUT /api/purchases/:id/status
// @access  Private/Admin
export const updatePurchaseStatus = asyncHandler(async (req, res) => {
  const { status, notes } = req.body;

  const purchase = await Purchase.findById(req.params.id);
  
  if (!purchase) {
    res.status(404);
    throw new Error("Purchase not found");
  }

  purchase.status = status;
  purchase.notes = notes || purchase.notes;
  
  if (status === "approved") {
    purchase.approvedBy = req.user._id;
    purchase.approvedAt = new Date();
  }

  await purchase.save();

  res.json({
    message: "Purchase status updated successfully",
    purchase
  });
});

// @desc    Delete purchase
// @route   DELETE /api/purchases/:id
// @access  Private/Admin
export const deletePurchase = asyncHandler(async (req, res) => {
  const purchase = await Purchase.findById(req.params.id);
  
  if (!purchase) {
    res.status(404);
    throw new Error("Purchase not found");
  }

  // If it's a fuel purchase, also delete the corresponding FuelStock entry
  if (purchase.purchaseType === "fuel") {
    await FuelStock.findOneAndDelete({ invoiceNumber: purchase.invoiceNumber });
  }

  await Purchase.findByIdAndDelete(req.params.id);

  res.json({ 
    message: "Purchase deleted successfully" 
  });
});