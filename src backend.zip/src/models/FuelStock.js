// models/FuelStock.js - FIXED ALERT LOGIC
import mongoose from "mongoose";

const fuelStockSchema = new mongoose.Schema({
  product: {
    type: String,
    required: [true, "Product name is required"],
    enum: ["Petrol", "Diesel", "CNG"]
  },
  tank: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "TankConfig",
    required: [true, "Tank is required"]
  },
  invoiceNumber: {
    type: String,
    required: [true, "Invoice number is required"],
    unique: true
  },
  purchaseQuantity: {
    type: Number,
    required: [true, "Purchase quantity is required"],
    min: 0
  },
  purchaseValue: {
    type: Number,
    required: [true, "Purchase value is required"],
    min: 0
  },
  vehicleNumber: {
    type: String,
    trim: true
  },
  density: {
    type: Number,
    min: 0
  },
  ratePerLiter: {
    type: Number,
    required: [true, "Rate per liter is required"],
    min: 0
  },
  supplier: {
    type: String,
    required: [true, "Supplier name is required"],
    trim: true
  },
  // Calculated fields
  openingStock: {
    type: Number,
    min: 0
  },
  closingStock: {
    type: Number,
    min: 0
  },
  currentLevel: {
    type: Number,
    min: 0,
    max: 100
  },
  alert: {
    type: Boolean,
    default: false
  },
  date: {
    type: Date,
    default: Date.now
  }
}, {
  timestamps: true
});

// In FuelStock.js - ensure this is correct
fuelStockSchema.pre("save", async function(next) {
  try {
    // Skip calculation for system adjustments
    if (this.supplier && this.supplier.includes("System -")) {
      console.log(`🔄 System adjustment - using provided values: Closing=${this.closingStock}L, Alert=${this.alert}`);
      return next();
    }

    const TankConfig = mongoose.model("TankConfig");
    const tank = await TankConfig.findById(this.tank);
    
    if (tank) {
      const latestStock = await mongoose.model("FuelStock")
        .findOne({ tank: this.tank })
        .sort({ createdAt: -1 });
      
      this.openingStock = latestStock ? latestStock.closingStock : 0;
      this.closingStock = this.openingStock + this.purchaseQuantity;
      this.currentLevel = Math.round((this.closingStock / tank.capacity) * 100);
      
      // FIXED: Alert when stock is LOW (below 20%)
      this.alert = this.currentLevel <= 20;
      
      console.log(`📊 Stock calculation: Opening=${this.openingStock}L, Purchase=${this.purchaseQuantity}L, Closing=${this.closingStock}L, Level=${this.currentLevel}%, Alert=${this.alert}`);
    }
    
    next();
  } catch (error) {
    console.error("❌ Error in pre-save hook:", error);
    next(error);
  }
});

// Update tank current stock after saving
fuelStockSchema.post("save", async function() {
  try {
    const TankConfig = mongoose.model("TankConfig");
    await TankConfig.findByIdAndUpdate(this.tank, {
      currentStock: this.closingStock,
      currentLevel: this.currentLevel,
      alert: this.alert, // Also update alert status in tank
      lastUpdated: new Date()
    });
    console.log(`🔄 Updated tank ${this.tank}: Stock=${this.closingStock}L, Level=${this.currentLevel}%, Alert=${this.alert}`);
  } catch (error) {
    console.error("❌ Error updating tank stock:", error);
  }
});

const FuelStock = mongoose.model("FuelStock", fuelStockSchema);
export default FuelStock;