import Audit from "../models/Audit.js";
import asyncHandler from "express-async-handler";

// Record audit
export const recordAudit = asyncHandler(async (req, res) => {
  const { module, description, createdBy } = req.body;
  const audit = await Audit.create({ module, description, createdBy, date: new Date() });
  res.status(201).json(audit);
});

// Get audits
export const getAudits = asyncHandler(async (req, res) => {
  const audits = await Audit.find().populate("createdBy");
  res.json(audits);
});


export const getAudit = async (req, res) => {
  try {
    // Example: fetch all audit records from DB
    const audits = await Audit.find().populate("user"); // assuming you have an Audit model
    res.status(200).json(audits);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Server error fetching audits" });
  }
};