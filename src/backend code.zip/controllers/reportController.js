import asyncHandler from "express-async-handler";
import Sale from "../models/Sale.js";
import Expense from "../models/Expense.js";
import Shift from "../models/Shift.js";
import Tank from "../models/FuelStock.js";
import User from "../models/User.js";
import Audit from "../models/Audit.js";

// Daily report
export const getDailyReport = asyncHandler(async (req, res) => {
  const { date } = req.query;
  const sales = await Sale.find({ date: { $gte: new Date(date), $lte: new Date(date + "T23:59:59") } });
  const expenses = await Expense.find({ date: { $gte: new Date(date), $lte: new Date(date + "T23:59:59") } });
  const shifts = await Shift.find({ startTime: { $gte: new Date(date), $lte: new Date(date + "T23:59:59") } });
  res.json({ sales, expenses, shifts });
});



// Shift report
export const getShiftReport = async (req, res) => {
  try {
    const shifts = await Shift.find().populate("nozzleman pump");
    res.status(200).json({ shifts });
  } catch (err) {
    res.status(500).json({ message: "Error fetching shift report", error: err.message });
  }
};

// Sales report
export const getSalesReport = async (req, res) => {
  try {
    const sales = await Sale.find().populate("nozzle product customer");
    res.status(200).json({ sales });
  } catch (err) {
    res.status(500).json({ message: "Error fetching sales report", error: err.message });
  }
};

// Stock report
export const getStockReport = async (req, res) => {
  try {
    const tanks = await Tank.find();
    res.status(200).json({ tanks });
  } catch (err) {
    res.status(500).json({ message: "Error fetching stock report", error: err.message });
  }
};

// Financial report
export const getFinancialReport = async (req, res) => {
  try {
    const sales = await Sale.find();
    const expenses = await Expense.find();
    res.status(200).json({ sales, expenses });
  } catch (err) {
    res.status(500).json({ message: "Error fetching financial report", error: err.message });
  }
};

// Employee report
export const getEmployeeReport = async (req, res) => {
  try {
    const users = await User.find({ role: "Nozzleman" });
    const shifts = await Shift.find().populate("nozzleman");
    res.status(200).json({ users, shifts });
  } catch (err) {
    res.status(500).json({ message: "Error fetching employee report", error: err.message });
  }
};

// Audit report
export const getAuditReport = async (req, res) => {
  try {
    const audits = await Audit.find().populate("shift sale stock");
    res.status(200).json({ audits });
  } catch (err) {
    res.status(500).json({ message: "Error fetching audit report", error: err.message });
  }
};
