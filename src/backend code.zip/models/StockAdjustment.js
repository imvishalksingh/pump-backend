// models/StockAdjustment.js
import mongoose from "mongoose";

const stockAdjustmentSchema = new mongoose.Schema({
  product: {
    type: String,
    required: [true, "Product name is required"],
    enum: ["Petrol", "Diesel", "CNG"]
  },
  adjustmentType: {
    type: String,
    required: [true, "Adjustment type is required"],
    enum: ["addition", "deduction", "calibration"]
  },
  quantity: {
    type: Number,
    required: [true, "Quantity is required"],
    min: 0
  },
  reason: {
    type: String,
    required: [true, "Reason is required"],
    trim: true
  },
  previousStock: {
    type: Number,
    required: true
  },
  newStock: {
    type: Number,
    required: true
  },
  adjustedBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "User",
    required: true
  },
  date: {
    type: Date,
    default: Date.now
  }
}, {
  timestamps: true
});

// Add index for better query performance
stockAdjustmentSchema.index({ product: 1, date: -1 });
stockAdjustmentSchema.index({ adjustedBy: 1 });

const StockAdjustment = mongoose.model("StockAdjustment", stockAdjustmentSchema);
export default StockAdjustment;