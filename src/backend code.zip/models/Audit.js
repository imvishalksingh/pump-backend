import mongoose from "mongoose";

const auditSchema = new mongoose.Schema({
  description: String,
  discrepancies: String,
  createdBy: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
}, { timestamps: true });

const Audit = mongoose.model("Audit", auditSchema);
export default Audit;
