import express from "express";
import { getAudits, getAudit } from "../controllers/auditController.js";
import { protect } from "../middleware/authMiddleware.js";
import { authorize } from "../middleware/roleMiddleware.js";

const router = express.Router();

router.use(protect);
router.use(authorize("Auditor", "Admin", "Manager"));

router.get("/", getAudits);
router.get("/:id", getAudit);

export default router;
