// routes/stockRoutes.js
import express from "express";
import {
  createFuelStock,
  getFuelStocks,
  getFuelStock,
  updateFuelStock,
  deleteFuelStock,
  getLatestStocks,
  getFuelStockStats,
  createStockAdjustment, // Add this import
  getStockAdjustments,   // Add this import
  getAdjustmentStats     // Add this import
} from "../controllers/fuelStockController.js";
import { protect } from "../middleware/authMiddleware.js";

const router = express.Router();

router.use(protect);

// Fuel stock routes
router.get("/", getFuelStocks);
router.get("/latest", getLatestStocks);
router.get("/stats", getFuelStockStats);
router.get("/:id", getFuelStock);
router.post("/", createFuelStock);
router.put("/:id", updateFuelStock);
router.delete("/:id", deleteFuelStock);

// ✅ ADD THESE NEW ROUTES FOR STOCK ADJUSTMENTS
router.post("/adjustment", createStockAdjustment);
router.get("/adjustments/history", getStockAdjustments);
router.get("/adjustments/stats", getAdjustmentStats);

export default router;