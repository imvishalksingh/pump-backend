// routes/settingsRoutes.js
import express from "express";
import { 
  getSettings, 
  updateSettings, 
  createBackup, 
  resetSettings 
} from "../controllers/settingsController.js";
import { protect } from "../middleware/authMiddleware.js";
import { authorize } from "../middleware/roleMiddleware.js";

const router = express.Router();

router.use(protect);
router.use(authorize("Admin"));

router.get("/", getSettings);
router.put("/", updateSettings);
router.post("/backup", createBackup);
router.post("/reset", resetSettings);

export default router;